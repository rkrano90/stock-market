package stock-market

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class UserStockSpec extends Specification implements DomainUnitTest<UserStock> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
