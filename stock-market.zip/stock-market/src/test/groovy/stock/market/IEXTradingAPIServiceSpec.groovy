package stock.market

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class IEXTradingAPIServiceSpec extends Specification implements ServiceUnitTest<IEXTradingAPIService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
