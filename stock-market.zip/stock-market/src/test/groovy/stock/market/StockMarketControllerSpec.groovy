package stock.market

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class StockMarketControllerSpec extends Specification implements ControllerUnitTest<StockMarketController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
