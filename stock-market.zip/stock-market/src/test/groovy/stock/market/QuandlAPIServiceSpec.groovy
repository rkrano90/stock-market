package stock.market

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class QuandlAPIServiceSpec extends Specification implements ServiceUnitTest<QuandlAPIService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
