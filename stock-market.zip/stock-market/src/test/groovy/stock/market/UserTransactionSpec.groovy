package stock.market

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class UserTransactionSpec extends Specification implements DomainUnitTest<UserTransaction> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
