package stock.market

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class AlphavantageAPIServiceSpec extends Specification implements ServiceUnitTest<AlphavantageAPIService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
